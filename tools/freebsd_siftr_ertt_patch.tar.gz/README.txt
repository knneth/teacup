FreeBSD SIFTR ERTT Patch
========================

This patch adds another column (column 27) to the output of SIFTR.
SIFTR is a FreeBSD kernel module that logs statistics on active TCP connections 
to a file. See https://www.freebsd.org/cgi/man.cgi?query=siftr&apropos=0&sektion=4&
manpath=FreeBSD+10.1-RELEASE&arch=default&format=html.

The additional column is the Enhanced Round Trip Time (ERTT) estimate 
computed by the ERTT module (see http://caia.swin.edu.au/urp/newtcp/tools.html), 
which is part of the FreeBSD kernel since FreeBSD version 9.x. The ERTT module
provides Enhanced RTT measurements for use by delay and rate based TCP
congestion control algorithms.

The patch works for FreeBSD versions 9.x to 10.1.


INSTALLATION
------------

Make sure you have the FreeBSD kernel source code installed. Then the modified 
SIFTR is installed as follows:

Change into the FreeBSD source directory and apply the patch:
> cd /usr/src/
> patch < FreeBSD-9.x-10.x_siftr_log_ertt.patch

Build and install the patched siftr module:
> cd /usr/src/sys/modules/siftr
> make
> make install

To run the SIFTR module use:
> kldload siftr


USAGE
-----

Consult the man page for SIFTR (e.g. man 4 siftr) on how to use SIFTR. This 
patch only adds another column to the output, it does not add any other 
functionality.


COPYRIGHT
---------

Copyright (c) 2013-2014 Centre for Advanced Internet Architectures,
Swinburne University of Technology. All rights reserved.

Author: Naeem Khademi (naeemk@ifi.uio.no)

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.