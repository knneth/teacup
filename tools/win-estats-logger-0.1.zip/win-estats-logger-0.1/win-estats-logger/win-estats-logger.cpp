// win-estats-logger
// 
// Copyright (c) 2013-2014, Centre for Advanced Internet Architectures, 
// Swinburne University of Technology. All rights reserved.
//
// Author: Sebastian Zander (szander@swin.edu.au)
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
//
// All the basic estats access frunctions are from MS example code provided here:
// http://msdn.microsoft.com/en-us/library/windows/desktop/bb485738%28v=vs.85%29.aspx
//
// Need to link with Iphlpapi.lib and Ws2_32.lib
// Need to run as administrator

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <winsock2.h>
#include <Ws2tcpip.h>
#include <iphlpapi.h>
#include <Tcpestats.h>
#include <stdlib.h>
#include <stdio.h>

// Need to link with Iphlpapi.lib
#pragma comment(lib, "iphlpapi.lib")

// Need to link with Ws2_32.lib
#pragma comment(lib, "ws2_32.lib")

// An array of name for the TCP_ESTATS_TYPE enum values
// The names values must match the enum values
wchar_t *estatsTypeNames[] = {
    L"TcpConnectionEstatsSynOpts",
    L"TcpConnectionEstatsData",
    L"TcpConnectionEstatsSndCong",
    L"TcpConnectionEstatsPath",
    L"TcpConnectionEstatsSendBuff",
    L"TcpConnectionEstatsRec",
    L"TcpConnectionEstatsObsRec",
    L"TcpConnectionEstatsBandwidth",
    L"TcpConnectionEstatsFineRtt",
    L"TcpConnectionEstatsMaximum"
};


/*
 * getopt variables and function
 */

int opterr = 1;             /* if error message should be printed */
int optind = 1;             /* index into parent argv vector */
int optopt;                 /* character checked for validity */
int optreset;               /* reset getopt */
char *optarg;               /* argument associated with option */
#define BADCH   (int)'?'
#define BADARG  (int)':'
#define EMSG    ""

/*
 * getopt -- parse argc/argv argument vector.
 */
int getopt(int nargc, char * const nargv[], const char *ostr)
{
  static char *place = EMSG;              /* option letter processing */
  char *oli;                              /* option letter list index */

  if (optreset || !*place) {              /* update scanning pointer */
    optreset = 0;
    if (optind >= nargc || *(place = nargv[optind]) != '-') {
      place = EMSG;
      return (-1);
    }
    if (place[1] && *++place == '-') {      /* found "--" */
      ++optind;
      place = EMSG;
      return (-1);
    }
  }                                       /* option letter okay? */
  if ((optopt = (int)*place++) == (int)':' ||
    !(oli = (char *) strchr(ostr, optopt))) {
      /*
      * if the user didn't specify '-' as an option,
      * assume it means -1.
      */
      if (optopt == (int)'-')
        return (-1);
      if (!*place)
        ++optind;
      if (opterr && *ostr != ':')
        (void)printf_s("illegal option -- %c\n", optopt);
      return (BADCH);
  }
  if (*++oli != ':') {                    /* don't need argument */
    optarg = NULL;
    if (!*place)
      ++optind;
  }
  else {                                  /* need an argument */
    if (*place)                     /* no white space */
      optarg = place;
    else if (nargc <= ++optind) {   /* no arg */
      place = EMSG;
      if (*ostr == ':')
        return (BADARG);
      if (opterr)
        (void)printf_s("option requires an argument -- %c\n", optopt);
      return (BADCH);
    }
    else                            /* white space */
      optarg = nargv[optind];
    place = EMSG;
    ++optind;
  }
  return (optopt);                        /* dump back option letter */
}


/*
 * getimeofday -- windows version of gettimeofday (only millisecond precision)
 *
 * timezone information is stored outside the kernel so tzp isn't used anymore.
 *
 * Note: this function is not for Win32 high precision timing purpose. See
 * elapsed_time().
 */

/* FILETIME of Jan 1 1970 00:00:00. */
//static const unsigned __int64 epoch = UINT64CONST(116444736000000000);
static const unsigned __int64 epoch = 116444736000000000;

int gettimeofday(struct timeval * tp, struct timezone * tzp)
{
     FILETIME file_time;
     SYSTEMTIME system_time;
     ULARGE_INTEGER ularge;
 
     GetSystemTime(&system_time);
     SystemTimeToFileTime(&system_time, &file_time);
     ularge.LowPart = file_time.dwLowDateTime;
     ularge.HighPart = file_time.dwHighDateTime;
 
     tp->tv_sec = (long) ((ularge.QuadPart - epoch) / 10000000L);
     tp->tv_usec = (long) (system_time.wMilliseconds * 1000);
 
     return 0;
}


/*
 * Estats functions
 */

/* print statistics */
void PrintStats(PUCHAR _dataRos, PUCHAR _dataRod, 
				PUCHAR _pathRos, PUCHAR _pathRod, PUCHAR _sndCongRos, PUCHAR _sndCongRod, 
				PUCHAR _recRos, PUCHAR _recRod, PUCHAR _obsRecRos, PUCHAR _obsRecRod,
				PUCHAR _synOptRos, PUCHAR _synOptRod, PUCHAR _sndBufRos, PUCHAR _sndBufRod)
{
	
	PTCP_ESTATS_SYN_OPTS_ROS_v0 synOptsRos = { 0 };
    PTCP_ESTATS_DATA_ROD_v0 dataRod = { 0 };
    PTCP_ESTATS_SND_CONG_ROD_v0 sndCongRod = { 0 };
    PTCP_ESTATS_SND_CONG_ROS_v0 sndCongRos = { 0 };
    PTCP_ESTATS_PATH_ROD_v0 pathRod = { 0 };
    PTCP_ESTATS_SEND_BUFF_ROD_v0 sndBuffRod = { 0 };
    PTCP_ESTATS_REC_ROD_v0 recRod = { 0 };
    PTCP_ESTATS_OBS_REC_ROD_v0 obsRecRod = { 0 };
    PTCP_ESTATS_BANDWIDTH_ROD_v0 bandwidthRod = { 0 };
    PTCP_ESTATS_FINE_RTT_ROD_v0 fineRttRod = { 0 };

	// Some variables that are not used by web10g
    // printf_s("\nEce Rcvd:            %u", pathRod->EceRcvd);
    // printf_s("\nQuench Rcvd:         %u", pathRod->QuenchRcvd);
    // printf_s("\nSnd Dup Ack Episodes:  %u", pathRod->SndDupAckEpisodes);
    // printf_s("\nAck After Fr:        %u", pathRod->AckAfterFr);
    // printf_s("\nLim Bytes Rwin:   %u", sndCongRod->SndLimBytesRwin);
    // printf_s("\nLim Bytes Cwnd:   %u", sndCongRod->SndLimBytesCwnd);      
    // printf_s("\nLim Bytes Snd:    %u", sndCongRod->SndLimBytesSnd);

	// Also the bandwidth and fine RTT statistics we don't output yet
      
    if (_dataRod != NULL && _pathRod != NULL && _sndCongRod != NULL &&
		_sndCongRos != NULL && _recRod != NULL && _obsRecRod != NULL &&
		_synOptRos != NULL && _sndBufRod != NULL) {

		dataRod = (PTCP_ESTATS_DATA_ROD_v0) _dataRod;
		pathRod = (PTCP_ESTATS_PATH_ROD_v0) _pathRod;
		sndCongRod = (PTCP_ESTATS_SND_CONG_ROD_v0) _sndCongRod;
        sndCongRos = (PTCP_ESTATS_SND_CONG_ROS_v0) _sndCongRos;
		recRod = (PTCP_ESTATS_REC_ROD_v0) _recRod;
		obsRecRod = (PTCP_ESTATS_OBS_REC_ROD_v0) _obsRecRod;
		synOptsRos = (PTCP_ESTATS_SYN_OPTS_ROS_v0) _synOptRos;
		sndBuffRod = (PTCP_ESTATS_SEND_BUFF_ROD_v0) _sndBufRod;
      
		printf_s("%u,", dataRod->SegsOut);
		printf_s("%lu,", dataRod->DataSegsOut);
		printf_s("%lu,", dataRod->DataBytesOut);
		printf_s("0,"); // HCDataOctetsOut
		printf_s("%u,", pathRod->PktsRetrans);
        printf_s("%u,", pathRod->BytesRetrans);
        printf_s("%u,", dataRod->SegsIn);
		printf_s("%lu,", dataRod->DataSegsIn);
        printf_s("%lu,", dataRod->DataBytesIn);
		printf_s("0,"); // HCDataOctetsIn
        printf_s("0,"); // ElapsedSecs      
		printf_s("0,"); // ElapsedMicroSecs
		printf_s("0,"); // StartTimeStamp
		printf_s("%u,", pathRod->CurMss);
		printf_s("0,"); // PipeSize
		printf_s("0,"); // MaxPipeSize
		printf_s("%u,", pathRod->SmoothedRtt);
		printf_s("%u,", pathRod->CurRto);
		printf_s("%u,", pathRod->CongSignals);
		printf_s("%u,", sndCongRod->CurCwnd);
		printf_s("%u,", sndCongRod->CurSsthresh);
        printf_s("%u,", pathRod->Timeouts);       
		printf_s("%u,", recRod->CurRwinSent);
        printf_s("%u,", recRod->MaxRwinSent);
		printf_s("%u,", recRod->MinRwinSent);
		printf_s("%u,", obsRecRod->CurRwinRcvd);
        printf_s("%u,", obsRecRod->MaxRwinRcvd);
		printf_s("%u,", obsRecRod->MinRwinRcvd);
		printf_s("%u,", sndCongRod->SndLimTransRwin);
		printf_s("%u,", sndCongRod->SndLimTransCwnd);
		printf_s("%u,", sndCongRod->SndLimTransSnd);
		printf_s("%u,", sndCongRod->SndLimTimeRwin);
		printf_s("%u,", sndCongRod->SndLimTimeCwnd);
		printf_s("%u,", sndCongRod->SndLimTimeSnd);
		printf_s("%u,", pathRod->RetranThresh);
		printf_s("%u,", pathRod->NonRecovDaEpisodes);
		printf_s("%u,", pathRod->SumBytesReordered);
		printf_s("%u,", pathRod->NonRecovDa);
		printf_s("%u,", pathRod->SampleRtt);
        printf_s("%u,", pathRod->RttVar);
		printf_s("%u,", pathRod->MaxRtt);
        printf_s("%u,", pathRod->MinRtt);
        printf_s("%u,", pathRod->SumRtt);
		printf_s("0,"); // HCSumRtt
		printf_s("%u,", pathRod->CountRtt);
        printf_s("%u,", pathRod->MaxRto);
        printf_s("%u,", pathRod->MinRto);
		printf_s("0,"); // IpTtl
		printf_s("0,"); // IpTosIn
		printf_s("0,"); // IpTosOut
	    printf_s("%u,", pathRod->PreCongSumCwnd);
        printf_s("%u,", pathRod->PreCongSumRtt);
        printf_s("%u,", pathRod->PostCongSumRtt);
        printf_s("%u,", pathRod->PostCongCountRtt);
        printf_s("%u,", pathRod->EcnSignals);
		printf_s("%u,", recRod->DupAckEpisodes);
		printf_s("0,"); // RcvRTT
		printf_s("%u,", recRod->DupAcksOut);
		printf_s("%u,", recRod->CeRcvd);
		printf_s("%u,", recRod->EcnSent);
		printf_s("%u,", synOptsRos->ActiveOpen);
		printf_s("%u,", synOptsRos->MssSent);
		printf_s("%u,", synOptsRos->MssRcvd);
		printf_s("%u", recRod->WinScaleSent);
		printf_s("%u,", obsRecRod->WinScaleRcvd);
		printf_s("0,"); // Timestamps
		printf_s("%u,", recRod->EcnNoncesRcvd);
		printf_s("0,"); // WillSendSACK
		printf_s("0,"); // WillUseSACK
		printf_s("0,"); // State
		printf_s("0,"); // Nagle
		printf_s("%u,", sndCongRod->MaxSsCwnd);
        printf_s("%u,", sndCongRod->MaxCaCwnd);
		printf_s("%u,", sndCongRod->MaxSsthresh);
        printf_s("%u,", sndCongRod->MinSsthresh);
        printf_s("0,"); // InRecovery
		printf_s("%u,", pathRod->DupAcksIn);
		printf_s("0,"); // SpuriousFrDetected
		printf_s("%u,", pathRod->SpuriousRtoDetections);
		printf_s("%u,", dataRod->SoftErrors);
        printf_s("%u,", dataRod->SoftErrorReason);
		printf_s("%u,", sndCongRod->SlowStart);
        printf_s("%u,", sndCongRod->CongAvoid);
		printf_s("%u,", sndCongRod->OtherReductions);
		printf_s("0,"); // CongAvoid
        printf_s("%u,", pathRod->FastRetran);
		printf_s("%u,", pathRod->SubsequentTimeouts);
        printf_s("%u,", pathRod->CurTimeoutCount);
        printf_s("%u,", pathRod->AbruptTimeouts); 
        printf_s("%u,", pathRod->SacksRcvd);
        printf_s("%u,", pathRod->SackBlocksRcvd);  
		printf_s("%u,", pathRod->SendStall);
		printf_s("%u,", pathRod->DsackDups); 
		printf_s("%u,", pathRod->MaxMss);
        printf_s("%u,", pathRod->MinMss);
		printf_s("0,"); // SndInitial
		printf_s("0,"); // RecInitial
		printf_s("%u,", sndBuffRod->CurRetxQueue);
        printf_s("%u,", sndBuffRod->MaxRetxQueue);
		printf_s("%u,", recRod->CurReasmQueue);
        printf_s("%u,", recRod->MaxReasmQueue);
		printf_s("%u,", dataRod->SndUna);
        printf_s("%u,", dataRod->SndNxt);
		printf_s("%u,", dataRod->SndMax);
		printf_s("%lu,", dataRod->ThruBytesAcked);
        printf_s("0,"); // HCThruOctetsAcked   
        printf_s("%u,", dataRod->RcvNxt);
        printf_s("%lu,", dataRod->ThruBytesReceived);
		printf_s("0,"); // HCThruOctetsReceived
		printf_s("%u,", sndBuffRod->CurAppWQueue);
        printf_s("%u,", sndBuffRod->MaxAppWQueue);
		printf_s("%u,", recRod->CurAppRQueue);
        printf_s("%u,", recRod->MaxAppRQueue);
		printf_s("%u", sndCongRos->LimCwnd);
		printf_s("0,"); // LimSsthresh
		printf_s("%u,", recRod->LimRwin);
        printf_s("0"); // LimMSS    
	}
}

/*
 * Enable or disable the supplied Estat type on a TCP connection.
 */
int ToggleEstat(PVOID row, TCP_ESTATS_TYPE type, bool enable, bool v6)
{
    TCP_BOOLEAN_OPTIONAL operation =
        enable ? TcpBoolOptEnabled : TcpBoolOptDisabled;
    ULONG status, size = 0;
    PUCHAR rw = NULL;
    TCP_ESTATS_DATA_RW_v0 dataRw;
    TCP_ESTATS_SND_CONG_RW_v0 sndRw;
    TCP_ESTATS_PATH_RW_v0 pathRw;
    TCP_ESTATS_SEND_BUFF_RW_v0 sendBuffRw;
    TCP_ESTATS_REC_RW_v0 recRw;
    TCP_ESTATS_OBS_REC_RW_v0 obsRecRw;
    TCP_ESTATS_BANDWIDTH_RW_v0 bandwidthRw;
    TCP_ESTATS_FINE_RTT_RW_v0 fineRttRw;

    switch (type) {
    case TcpConnectionEstatsData:
        dataRw.EnableCollection = enable;
        rw = (PUCHAR) & dataRw;
        size = sizeof (TCP_ESTATS_DATA_RW_v0);
        break;

    case TcpConnectionEstatsSndCong:
        sndRw.EnableCollection = enable;
        rw = (PUCHAR) & sndRw;
        size = sizeof (TCP_ESTATS_SND_CONG_RW_v0);
        break;

    case TcpConnectionEstatsPath:
        pathRw.EnableCollection = enable;
        rw = (PUCHAR) & pathRw;
        size = sizeof (TCP_ESTATS_PATH_RW_v0);
        break;

    case TcpConnectionEstatsSendBuff:
        sendBuffRw.EnableCollection = enable;
        rw = (PUCHAR) & sendBuffRw;
        size = sizeof (TCP_ESTATS_SEND_BUFF_RW_v0);
        break;

    case TcpConnectionEstatsRec:
        recRw.EnableCollection = enable;
        rw = (PUCHAR) & recRw;
        size = sizeof (TCP_ESTATS_REC_RW_v0);
        break;

    case TcpConnectionEstatsObsRec:
        obsRecRw.EnableCollection = enable;
        rw = (PUCHAR) & obsRecRw;
        size = sizeof (TCP_ESTATS_OBS_REC_RW_v0);
        break;

    case TcpConnectionEstatsBandwidth:
        bandwidthRw.EnableCollectionInbound = operation;
        bandwidthRw.EnableCollectionOutbound = operation;
        rw = (PUCHAR) & bandwidthRw;
        size = sizeof (TCP_ESTATS_BANDWIDTH_RW_v0);
        break;

    case TcpConnectionEstatsFineRtt:
        fineRttRw.EnableCollection = enable;
        rw = (PUCHAR) & fineRttRw;
        size = sizeof (TCP_ESTATS_FINE_RTT_RW_v0);
        break;

    default:
        return ERROR_NOT_FOUND;
        break;
    }

    if (v6) {
        status = SetPerTcp6ConnectionEStats((PMIB_TCP6ROW) row, type,
                                            rw, 0, size, 0);
    } else {
        status = SetPerTcpConnectionEStats((PMIB_TCPROW) row, type,
                                           rw, 0, size, 0);
    }

	return status;
}

/*
 * Toggle all Estats for a TCP connection.
 */
int ToggleAllEstats(void *row, bool enable, bool v6)
{
	int ret;

    ret = ToggleEstat(row, TcpConnectionEstatsData, enable, v6);
	if (ret != NO_ERROR) {
			return ret;
	}
    ret = ToggleEstat(row, TcpConnectionEstatsSndCong, enable, v6);
	if (ret != NO_ERROR) {
			return ret;
	}
    ret = ToggleEstat(row, TcpConnectionEstatsPath, enable, v6);
	if (ret != NO_ERROR) {
			return ret;
	}
    ret = ToggleEstat(row, TcpConnectionEstatsSendBuff, enable, v6);
	if (ret != NO_ERROR) {
			return ret;
	}
    ret = ToggleEstat(row, TcpConnectionEstatsRec, enable, v6);
	if (ret != NO_ERROR) {
			return ret;
	}
    ret = ToggleEstat(row, TcpConnectionEstatsObsRec, enable, v6);
	if (ret != NO_ERROR) {
			return ret;
	}
    ret = ToggleEstat(row, TcpConnectionEstatsBandwidth, enable, v6);
	if (ret != NO_ERROR) {
			return ret;
	}
    ret = ToggleEstat(row, TcpConnectionEstatsFineRtt, enable, v6);

	return ret;
}


/* return the size of the memory buffers for the stats */
int GetStatSize(TCP_ESTATS_TYPE type, __out ULONG *rosSize, ULONG *rodSize)
{
	*rosSize = 0;
	*rodSize = 0;

	 switch (type) {
		case TcpConnectionEstatsSynOpts:
			*rosSize = sizeof (TCP_ESTATS_SYN_OPTS_ROS_v0);
			break;
		case TcpConnectionEstatsData:
			*rodSize = sizeof (TCP_ESTATS_DATA_ROD_v0);
			break;
		case TcpConnectionEstatsSndCong:
			*rodSize = sizeof (TCP_ESTATS_SND_CONG_ROD_v0);
			*rosSize = sizeof (TCP_ESTATS_SND_CONG_ROS_v0);
			break;
		case TcpConnectionEstatsPath:
			*rodSize = sizeof (TCP_ESTATS_PATH_ROD_v0);
			break;
		case TcpConnectionEstatsSendBuff:
			*rodSize = sizeof (TCP_ESTATS_SEND_BUFF_ROD_v0);
			break;
		case TcpConnectionEstatsRec:
			*rodSize = sizeof (TCP_ESTATS_REC_ROD_v0);
			break;
		case TcpConnectionEstatsObsRec:
			*rodSize = sizeof (TCP_ESTATS_OBS_REC_ROD_v0);
			break;
		case TcpConnectionEstatsBandwidth:
			*rodSize = sizeof (TCP_ESTATS_BANDWIDTH_ROD_v0);
			break;
		case TcpConnectionEstatsFineRtt:
			*rodSize = sizeof (TCP_ESTATS_FINE_RTT_ROD_v0);
			break;

		default:
			return ERROR_NOT_FOUND;
			break;
	}

	 return NO_ERROR;
}


/* allocate memory for stats group */
int AllocMem(TCP_ESTATS_TYPE type,  __out PUCHAR *ros, __out PUCHAR *rod)
{
	int ret;
	ULONG rosSize = 0, rodSize = 0;

	ret = GetStatSize(type, &rosSize, &rodSize);
	if (ret != NO_ERROR) {
		return ret;
	}
	
	if (rosSize != 0) {
		*ros = (PUCHAR) malloc(rosSize);
		if (*ros == NULL) {
			return ERROR_OUTOFMEMORY;
		}
		else
			memset(*ros,0, rosSize); // zero the buffer
	}
	if (rodSize != 0) {
		*rod = (PUCHAR) malloc(rodSize);
		if (*rod == NULL) {
			free(*ros);
			return ERROR_OUTOFMEMORY;
		}
		else
			memset(*rod,0, rodSize); // zero the buffer
	}

	return NO_ERROR;
}


int AllocAllMem(PUCHAR *_dataRos, PUCHAR *_dataRod, PUCHAR *_pathRos, 
			PUCHAR *_pathRod, PUCHAR *_sndCongRos, PUCHAR *_sndCongRod, 
			PUCHAR *_recRos, PUCHAR *_recRod, PUCHAR *_obsRecRos, PUCHAR *_obsRecRod,
			PUCHAR *_synOptRos, PUCHAR *_synOptRod, PUCHAR *_sndBufRos,	PUCHAR *_sndBufRod)
{
	int ret;

	ret = AllocMem(TcpConnectionEstatsData, _dataRos, _dataRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = AllocMem(TcpConnectionEstatsPath, _pathRos, _pathRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = AllocMem(TcpConnectionEstatsSndCong, _sndCongRos, _sndCongRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = AllocMem(TcpConnectionEstatsRec, _recRos, _recRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = AllocMem(TcpConnectionEstatsObsRec, _obsRecRos, _obsRecRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = AllocMem(TcpConnectionEstatsSynOpts, _synOptRos, _synOptRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = AllocMem(TcpConnectionEstatsSendBuff, _sndBufRos, _sndBufRod);
	return ret;

}


/* get stats group */
int GetEstats(void *row, TCP_ESTATS_TYPE type, bool v6, __out PUCHAR ros, __out PUCHAR rod)
{
    ULONG rosSize = 0, rodSize = 0;
    int ret;
    
	ret = GetStatSize(type, &rosSize, &rodSize);
	if (ret != NO_ERROR) {
		return ret;
	}

    if (v6) {
        ret = GetPerTcp6ConnectionEStats((PMIB_TCP6ROW) row,
                                          type,
                                          NULL, 0, 0,
                                          ros, 0, rosSize,
                                          rod, 0, rodSize);
    } else {
        ret = GetPerTcpConnectionEStats((PMIB_TCPROW) row,
                                         type,
                                         NULL, 0, 0,
                                         ros, 0, rosSize, rod, 0, rodSize);
    }
    
	return ret;
}



int GetAllEstats(void *row, bool v6, PUCHAR _dataRos, PUCHAR _dataRod, 
				PUCHAR _pathRos, PUCHAR _pathRod, PUCHAR _sndCongRos, PUCHAR _sndCongRod, 
				PUCHAR _recRos, PUCHAR _recRod, PUCHAR _obsRecRos, PUCHAR _obsRecRod,
				PUCHAR _synOptRos, PUCHAR _synOptRod, PUCHAR _sndBufRos, PUCHAR _sndBufRod)
{
	int ret;

	ret = GetEstats(row, TcpConnectionEstatsData, v6, _dataRos, _dataRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = GetEstats(row, TcpConnectionEstatsPath, v6, _pathRos, _pathRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = GetEstats(row, TcpConnectionEstatsSndCong, v6, _sndCongRos, _sndCongRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = GetEstats(row, TcpConnectionEstatsRec, v6, _recRos, _recRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = GetEstats(row, TcpConnectionEstatsObsRec, v6, _obsRecRos, _obsRecRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = GetEstats(row, TcpConnectionEstatsSynOpts, v6, _synOptRos, _synOptRod);
	if (ret != NO_ERROR) {
		return ret;
	}
	ret = GetEstats(row, TcpConnectionEstatsSendBuff, v6, _sndBufRos, _sndBufRod);
	return ret;

}


/* Get all IPv4 flows */
int GetTcpRows(MIB_TCP_STATE state, __out MIB_TCPROW rows[], u_short nrows, __out u_short *cnt)
{
    PMIB_TCPTABLE tcpTable = NULL;
    PMIB_TCPROW tcpRowIt = NULL;
    DWORD status, size = 0, i;
    
    status = GetTcpTable(tcpTable, &size, TRUE);
    if (status != ERROR_INSUFFICIENT_BUFFER) {
        return status;
    }

    tcpTable = (PMIB_TCPTABLE) malloc(size);
    if (tcpTable == NULL) {
        return ERROR_OUTOFMEMORY;
    }

    status = GetTcpTable(tcpTable, &size, TRUE);
    if (status != ERROR_SUCCESS) {
        free(tcpTable);
        return status;
    }

	*cnt = 0;
    for (i = 0; i < tcpTable->dwNumEntries && i < nrows; i++) {
        tcpRowIt = &tcpTable->table[i];
		if (tcpRowIt->dwState > 2) {
			// must be at least in MIB_TCP_STATE_SYN_SENT state
            rows[*cnt] = *tcpRowIt;
			(*cnt)++;
        }
    }

    free(tcpTable);

    return NO_ERROR;
}


/* Get all IPv6 flows */
int GetTcp6Rows(MIB_TCP_STATE state, __out MIB_TCP6ROW rows[], u_short nrows, __out u_short *cnt)
{
    PMIB_TCP6TABLE tcp6Table = NULL;
    PMIB_TCP6ROW tcp6RowIt = NULL;
    DWORD status, size = 0, i;

    status = GetTcp6Table(tcp6Table, &size, TRUE);
    if (status != ERROR_INSUFFICIENT_BUFFER) {
        return status;
    }

    tcp6Table = (PMIB_TCP6TABLE) malloc(size);
    if (tcp6Table == NULL) {
        return ERROR_OUTOFMEMORY;
    }

    status = GetTcp6Table(tcp6Table, &size, TRUE);
    if (status != ERROR_SUCCESS) {
        free(tcp6Table);
        return status;
    }

	*cnt = 0;
    for (i = 0; i < tcp6Table->dwNumEntries && i < nrows; i++) {
        tcp6RowIt = &tcp6Table->table[i];
		if (tcp6RowIt->State > 2) {
			// must be at least in MIB_TCP_STATE_SYN_SENT state
            rows[*cnt] = *tcp6RowIt;
			(*cnt)++;
        }
    }

    free(tcp6Table);

    return NO_ERROR;
}



/* 
 * usage -- print usage information
 */

void usage()
{
	 wprintf_s(L"\n\n");
     wprintf_s(L"Usage: win-estats-logger [-e exclude_ip] [-i interval]\n");
}


/*
 * main function
 */

int __cdecl main(int argc,      // Number of strings in array argv
				char *argv[],   // Array of command-line argument strings
				char *envp[] )  // Array of environment variable strings
{
	struct timeval now;
	MIB_TCPROW connRows[256];
	u_short cnt;
	int opt;
	int ret;
	unsigned int poll_interval = 1000; // 1 second
	int quiet = 0;
	char exclude_ip[64];
	WSADATA wsaData;

	// pointers to memory for the stats
	PUCHAR dataRos = NULL, dataRod = NULL;
	PUCHAR pathRos = NULL, pathRod = NULL;
	PUCHAR sndCongRos = NULL, sndCongRod = NULL;
	PUCHAR recRos = NULL, recRod = NULL;
	PUCHAR obsRecRos = NULL, obsRecRod = NULL;
	PUCHAR synOptRos = NULL, synOptRod = NULL;
	PUCHAR sndBufRos = NULL, sndBufRod = NULL;

	// Initialize Winsock (needed for getaddrinfo)
    if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)) {
        fprintf_s(stderr, "WSAStartup failed: %d\n", ret);
        exit(EXIT_FAILURE);
    }

	// allocate memory
	if (AllocAllMem(&dataRos, &dataRod, &pathRos, &pathRod, &sndCongRos, 
				  &sndCongRod, &recRos, &recRod, &obsRecRos, &obsRecRod,
				  &synOptRos, &synOptRod, &sndBufRos, &sndBufRod) != NO_ERROR) {
			goto bail;
	}

	// parse options

	while ((opt = getopt(argc, argv, "e:hi:q")) != -1) {
			switch (opt) {
                case 'h':
                        usage();
                        exit(EXIT_SUCCESS);
                        break;

                case 'e':
					{
                        struct sockaddr_in sa;
                        struct addrinfo hints;
                        struct addrinfo *result;

                        strncpy_s(exclude_ip, optarg, sizeof(exclude_ip));

                        memset(&hints, 0, sizeof(struct addrinfo));
                        hints.ai_family = AF_INET;    /* Allow IPv4 or IPv6 */
                        hints.ai_socktype = SOCK_DGRAM; /* Datagram socket */
                        hints.ai_flags = 0;
                        hints.ai_protocol = 0;          /* Any protocol */

                        if ((ret = getaddrinfo(exclude_ip, NULL, &hints, &result) != 0)) {
								// XXX to output of gai_strerror seems to be not helpful/nonsense on Windows
                                fprintf_s(stderr, "getaddrinfo: %d %s\n", ret, gai_strerror(ret));
                                exit(EXIT_FAILURE);
                        }
                        strcpy_s(exclude_ip, inet_ntoa(((struct sockaddr_in *) result->ai_addr)->sin_addr));
                        
                        freeaddrinfo(result);

                        if (inet_pton(AF_INET, exclude_ip, &(sa.sin_addr)) == 0) {
                                fprintf_s(stderr, "Exclude IP '%s' is not a valid IP address\n", exclude_ip);
                                exit(EXIT_FAILURE);
                        }
                     }
                     break;

				case 'i':
                        {
                        char *endptr;
                        double x = strtod(optarg, &endptr);

                        /* check for various possible errors */
                        if (endptr == optarg) {
                                wprintf_s(L"Poll interval must be a floating point number\n");
                                exit(EXIT_FAILURE);
                        }
                        if (x > 1.0) {
                                wprintf_s(L"Maximum poll interval is 1 second\n");
                                exit(EXIT_FAILURE);
                        }
                        if (x < 0.001) {
                                wprintf_s(L"Minimum poll interval is 0.001 second (1ms)\n");
                                exit(EXIT_FAILURE);
                        }

                        poll_interval = (unsigned int) (x * 1000);
                        }

                        break;

				case 'q':
						quiet = 1;
						break;

                default:
                        exit(EXIT_FAILURE);
                        break;
            }
	 }

	if (!quiet) {
			printf_s("win-estats-logger version 0.1\n");
			printf_s("poll interval is %u ms\n", poll_interval);
	}

	while (1) {
		
		gettimeofday(&now, NULL);
		
		// XXX only IPv4 for now
		GetTcpRows(MIB_TCP_STATE_ESTAB, connRows, 256, &cnt);
		
		for (u_short i=0; i < cnt; i++) {
				IN_ADDR localAddr;
				IN_ADDR remoteAddr;
				char ip[16];

				// turn on all estats
				if (ToggleAllEstats(&connRows[i], TRUE, FALSE) != NO_ERROR) {
						// if we can't enable then skip this flow
						continue;
				}

				localAddr.S_un.S_addr = (u_long) connRows[i].dwLocalAddr;
				remoteAddr.S_un.S_addr = (u_long) connRows[i].dwRemoteAddr;
				
				sprintf_s(ip, "%s", inet_ntoa(localAddr));
				if (strcmp(exclude_ip, ip) == 0) {
						// exclude this source
						continue;
				}

				if (GetAllEstats(&connRows[i], FALSE, dataRos, dataRod, pathRos, 
								pathRod, sndCongRos, sndCongRod, recRos, recRod, 
								obsRecRos, obsRecRod, synOptRos, synOptRod, sndBufRos, 
								sndBufRod) == NO_ERROR) {

					printf_s("%u.%06u,0,%s,%u,", now.tv_sec, now.tv_usec, ip, 
						ntohs((u_short) connRows[i].dwLocalPort));
					sprintf_s(ip, "%s", inet_ntoa(remoteAddr));
					printf_s("%s,%u,", ip, ntohs((u_short) connRows[i].dwRemotePort));
					PrintStats(dataRos, dataRod, pathRos, 
								pathRod, sndCongRos, sndCongRod, recRos, recRod, 
								obsRecRos, obsRecRod, synOptRos, synOptRod, sndBufRos, 
								sndBufRod);
					printf_s("\n");
				}
		}

		Sleep(poll_interval);
	}

bail:
    
	free(dataRod);
	free(dataRos);
	free(pathRod);
	free(pathRos);
	free(sndCongRod);
	free(sndCongRos);
	free(recRod);
	free(recRos);
	free(obsRecRod);
	free(obsRecRos);
	free(synOptRod);
	free(synOptRos);
	free(sndBufRod);
	free(sndBufRos);

	WSACleanup();

    return (0);
}
