TCP Extended Statics MIB Logger for Windows
===========================================

The TCP Extended Statics MIB Logger (win-estats-logger) is a tool to 
log the statistics collected by the EStats MIB inside the kernel for 
all active TCP flows.

win-estats-logger polls the MIB in regular user definable intervals.

It is based on example code from MS: 
http://msdn.microsoft.com/en-us/library/windows/desktop/bb485738%28v=vs.85%29.aspx

We have tested win-estats-logger under Windows 7 32bit and Windows 7 
64bit.

DIRECTORIES
-----------

The tar file contains the following directories:
Debug: 			executable built with debug options
Release:                executable for Windows 32bit
win-estats-logger:      source files and MS Visual Studio files
x64:                    executable for Windows 64bit


INSTALLATION
------------

To install win-estats-logger simply copy the executable into a 
directory that is in the path such as C:\Windows\System32\ or 
create a directory under C:\Program Files (x86)\ and add the 
directory to the path.

Make sure to copy the 32bit version if you run Windows 32bit or the 
64bit version if you run Windows 64bit.

To run win-estats-logger you need the MS Visual C++ 2010 Redistributable
for 32bit and/or 64bit depending on which version of win-estats-logger 
you want to run. Most likely this is already installed on your system, 
but if it is missing you can download it from here:
http://www.microsoft.com/en-AU/download/details.aspx?id=5555 (32bit version)
http://www.microsoft.com/en-us/download/details.aspx?id=14632 (64bit version)

USAGE
-----

To run win-estats-logger just type:

> win-estats-logger

The tool has two command line parameters. The -e switch make it 
possible to ignore flows from or to a specific IP address and 
the -i switch allows to specify the poll interval in seconds. 
The smallest poll interval is 0.001 seconds (1 millisecond).

The following command runs win-estats-logger with flows from/to
192.168.0.10 excluded and will print out TCP statistics every
100ms.

> win-estats-logger -e 192.168.0.10 -i 0.1

OUTPUT
------

The output format is a comma-separated list of TCP statistics, with one
line printed per flow per poll time where the flow is active (according
to the EStats MIB).

The file web10g-logger-fields.txt specifies the name for each
field in the comma-separated list and the file web10g-logger-fields-
description.txt explains each field. 

Note that not all fields listed in web10g-logger-fields-description.txt 
are used by win-estats-logger. Also note that a few fields in the output 
are not actually present in the Windows version implementation of the 
Estats MIB and their values are always zero. This is so the printed out 
list of parameters is compatible with the web10g-logger tool from the web10g 
userland tools (http://www.web10g.org/).

Currently, you need to check the source code to find out which fields
are not implemented. 

COPYRIGHT
---------

Copyright (c) 2013-2014 Centre for Advanced Internet Architectures,
Swinburne University of Technology. All rights reserved.

Author: Sebastian Zander (szander@swin.edu.au)

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.